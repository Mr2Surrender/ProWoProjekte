/*
  Four_Digital_Display.h

  This is a Suli-compatible Library.

  2014 Copyright (c) Seeed Technology Inc.  All right reserved.

  Author:Loovee
  2014-4-9

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


#ifndef __AS_Four_Digit_Display_H__
#define __AS_Four_Digit_Display_H__
#include "AS_Suli.h"


//************definitions for TM1637*********************
#define AS_ADDR_AUTO  0x40
#define AS_ADDR_FIXED 0x44

#define AS_STARTADDR  0xc0
/**** definitions for the clock point of the digit tube *******/
#define AS_POINT_ON   1
#define AS_POINT_OFF  0
/**************definitions for brightness***********************/
//#define  AS_BRIGHT_DARKEST 0
//#define  AS_BRIGHT_TYPICAL 2
//#define  AS_BRIGHTEST      7


enum AS_brightness_t
{
    AS_BRIGHT_DARKEST = 0,
    AS_BRIGHT_TYPICAL = 2,
    AS_BRIGHTEST      = 7
};


void AS_four_digit_init(AS_PIN_T data, AS_PIN_T clk);                // init

void AS_four_digit_set_brightness(enum AS_brightness_t b);        // set before calling display
void AS_four_digit_set_point(bool disp_point);                 // set before calling display
void AS_Four_Digit_Display(uint8 BitAddr,int8 DispData);
void AS_four_digit_clear();

#endif
